// Función serverless para Vercel.
// Ruta resultante: /api/generate-recipe
// Requiere la variable de entorno ANTHROPIC_API_KEY configurada en el proyecto de Vercel.

const rules = require('../data/rules.json');

module.exports = async function handler(req, res) {
  if (req.method !== 'POST') {
    res.status(405).json({ error: 'Método no permitido' });
    return;
  }

  const {
    metodo,        // clave del método, ej: "v60"
    variedad,
    origen,
    altitud,
    proceso,
    tueste,
    notas
  } = req.body || {};

  const regla = rules[metodo];
  if (!regla) {
    res.status(400).json({ error: `Método desconocido: ${metodo}` });
    return;
  }

  const carrilTexto = `
Método: ${regla.nombre}
Ratio permitido (café:agua, o dosis:rendimiento en espresso): mínimo 1:${regla.ratio.min}, ideal 1:${regla.ratio.ideal}, máximo 1:${regla.ratio.max}. NUNCA salgas de este rango.
${regla.temperatura_c ? `Temperatura permitida: mínimo ${regla.temperatura_c.min}°C, ideal ${regla.temperatura_c.ideal}°C, máximo ${regla.temperatura_c.max}°C. NUNCA salgas de este rango.` : 'Este método no tiene control real de temperatura de agua (ver notas).'}
Molienda permitida: mínimo ${regla.molienda_micrones.min} micrones, ideal ${regla.molienda_micrones.ideal} micrones, máximo ${regla.molienda_micrones.max} micrones (textura de referencia: ${regla.molienda_micrones.textura}). NUNCA salgas de este rango.
Notas del método: ${regla.notas}
Criterio de altitud/densidad del proyecto: ${rules.criterio_altitud_densidad}
`.trim();

  const prompt = `Eres un Q-grader y barista experto ayudando a generar una receta de café. Debes respetar ESTRICTAMENTE los carriles (rangos) que se te dan a continuación — son límites duros definidos por un barista profesional, no sugerencias.

${carrilTexto}

Perfil del café a preparar:
- Variedad: ${variedad || 'no especificada'}
- Origen: ${origen || 'no especificado'}
- Altitud: ${altitud ? altitud + ' msnm' : 'no especificada'}
- Proceso/beneficio: ${proceso || 'no especificado'}
- Nivel de tueste: ${tueste || 'no especificado'}
- Notas de cata deseadas: ${notas || 'no especificadas'}

Responde SOLO con un JSON válido, sin texto adicional, sin markdown, con esta forma exacta:
{"ratio": "1:16", "molienda": "descripción con textura de referencia", "temperatura": "94°C o N/A si no aplica", "justificacion": "2-3 frases explicando el porqué de estos valores dentro del carril, considerando altitud, proceso y tueste"}`;

  try {
    const response = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': process.env.ANTHROPIC_API_KEY,
        'anthropic-version': '2023-06-01'
      },
      body: JSON.stringify({
        model: 'claude-sonnet-4-6',
        max_tokens: 500,
        messages: [{ role: 'user', content: prompt }]
      })
    });

    if (!response.ok) {
      const errText = await response.text();
      res.status(502).json({ error: 'Error llamando a la API de Claude', detalle: errText });
      return;
    }

    const data = await response.json();
    const text = data.content.map((b) => b.text || '').join('');
    const clean = text.replace(/```json|```/g, '').trim();
    const receta = JSON.parse(clean);

    res.status(200).json(receta);
  } catch (err) {
    res.status(500).json({ error: 'Error generando la receta', detalle: String(err) });
  }
};
