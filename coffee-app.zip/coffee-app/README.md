# Generador de recetas de café — prototipo

## Qué es esto
- `index.html` — el formulario que ve el usuario.
- `api/generate-recipe.js` — función de servidor que llama a la API de Claude. Aquí vive tu clave de API, nunca en el navegador.
- `data/rules.json` — los carriles (ratio, temperatura, molienda) por método que definimos juntos. Esto es lo que le pone límites a la IA para que no invente fuera de rango.

## Cómo subirlo (recomendado: Vercel)

1. Crea una cuenta gratuita en https://vercel.com (puedes entrar con GitHub).
2. Sube esta carpeta a un repositorio de GitHub (puedes arrastrar los archivos directamente en github.com > "Add file" > "Upload files", no necesitas usar la terminal si no quieres).
3. En Vercel, click en "Add New… > Project" e importa ese repositorio.
4. Antes de darle a "Deploy", ve a la sección **Environment Variables** y agrega:
   - Nombre: `ANTHROPIC_API_KEY`
   - Valor: tu clave de API de Anthropic (la consigues en https://console.anthropic.com, sección "API Keys" — necesitas crear una cuenta de desarrollador ahí, que es distinta de tu cuenta de claude.ai)
5. Dale a "Deploy". En 1-2 minutos Vercel te da una URL pública (algo como `tu-proyecto.vercel.app`) donde la app ya funciona para cualquiera que la visite.

## Alternativa sin GitHub
Vercel también tiene un CLI (`npm i -g vercel`, luego `vercel` dentro de la carpeta) si prefieres subirlo directo desde tu computadora sin pasar por GitHub. El paso de la variable de entorno es el mismo.

## Probarlo en tu computadora antes de subirlo (opcional)
Si tienes Node.js instalado:
```
npm i -g vercel
vercel dev
```
Te va a pedir la misma variable de entorno (`ANTHROPIC_API_KEY`) y te da una URL local (`localhost:3000`) para probar todo antes de publicarlo.

## Costos
Cada receta generada consume tokens de la API de Claude (esto es aparte de tu suscripción a claude.ai — es la API de desarrollador, se paga por uso, muy barato para este volumen: fracciones de centavo por receta). Vercel es gratis en su plan hobby para este nivel de tráfico.

## Siguiente paso natural
Ahora mismo cada método vive "hardcodeado" en `rules.json`. Cuando quieras conectar la base de datos de molinos (para traducir la molienda a clicks de un molino específico), ese sería otro archivo de datos y otra función, siguiendo el mismo patrón.
